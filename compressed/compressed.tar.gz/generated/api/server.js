var express = require('express');
var routes = require('./app/routes');
var exp = express();
var bodyParser = require('body-parser')

exp.use(bodyParser.json());       // to support JSON-encoded bodies
exp.use(bodyParser.urlencoded({     // to support URL-encoded bodies
  extended: true
}));


exp.get('/ovens/',routes.oven.get_ovens_33);

exp.get('/ovens/:id',routes.oven.get_ovens_34);

exp.put('/ovens/:id',routes.oven.put_ovens_35);

exp.delete('/ovens/:id',routes.oven.delete_ovens_36);

exp.post('/ovens/',routes.oven.post_ovens_37);

exp.get('/pallets/',routes.pallet.get_pallets_38);

exp.get('/pallets/:id',routes.pallet.get_pallets_39);

exp.put('/pallets/:id',routes.pallet.put_pallets_40);

exp.delete('/pallets/:id',routes.pallet.delete_pallets_41);

exp.post('/pallets/',routes.pallet.post_pallets_42);

exp.post('/pallets/:id/parts',routes.pallet.post_parts_in_pallets_43);

exp.get('/pallets/:id/parts',routes.pallet.get_parts_in_pallets_44);

exp.get('/pallets/:id/parts/:part_id',routes.pallet.get_parts_in_pallets_45);

exp.put('/pallets/:id/parts/:part_id',routes.pallet.put_parts_in_pallets_46);

exp.delete('/pallets/:id/parts/:part_id',routes.pallet.delete_parts_in_pallets_47);

exp.get('/locations/',routes.location.get_locations_48);

exp.get('/locations/:id',routes.location.get_locations_49);

exp.put('/locations/:id',routes.location.put_locations_50);

exp.delete('/locations/:id',routes.location.delete_locations_51);

exp.post('/locations/',routes.location.post_locations_52);

exp.get('/parts/',routes.part.get_parts_53);

exp.get('/parts/:id',routes.part.get_parts_54);

exp.put('/parts/:id',routes.part.put_parts_55);

exp.delete('/parts/:id',routes.part.delete_parts_56);

exp.post('/parts/',routes.part.post_parts_57);

exp.get('/parts/:id/pallets',routes.part.get_pallets_in_parts_58);

exp.post('/parts/:id/pallets',routes.part.post_pallets_in_parts_59);


console.log('The application is listening at port 3001');
exp.listen(3001);