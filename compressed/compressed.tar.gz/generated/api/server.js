var express = require('express');
var routes = require('./app/routes');
var exp = express();
var bodyParser = require('body-parser')

exp.use(bodyParser.json());       // to support JSON-encoded bodies
exp.use(bodyParser.urlencoded({     // to support URL-encoded bodies
  extended: true
}));


exp.get('/ovens/',routes.oven.get_ovens_w);

exp.get('/ovens/:id',routes.oven.get_ovens_x);

exp.put('/ovens/:id',routes.oven.put_ovens_y);

exp.delete('/ovens/:id',routes.oven.delete_ovens_z);

exp.post('/ovens/',routes.oven.post_ovens_10);

exp.get('/pallets/',routes.pallet.get_pallets_11);

exp.get('/pallets/:id',routes.pallet.get_pallets_12);

exp.put('/pallets/:id',routes.pallet.put_pallets_13);

exp.delete('/pallets/:id',routes.pallet.delete_pallets_14);

exp.post('/pallets/',routes.pallet.post_pallets_15);

exp.post('/pallets/:id/parts',routes.pallet.post_parts_in_pallets_16);

exp.get('/pallets/:id/parts',routes.pallet.get_parts_in_pallets_17);

exp.get('/pallets/:id/parts/:part_id',routes.pallet.get_parts_in_pallets_18);

exp.put('/pallets/:id/parts/:part_id',routes.pallet.put_parts_in_pallets_19);

exp.delete('/pallets/:id/parts/:part_id',routes.pallet.delete_parts_in_pallets_1a);

exp.get('/locations/',routes.location.get_locations_1b);

exp.get('/locations/:id',routes.location.get_locations_1c);

exp.put('/locations/:id',routes.location.put_locations_1d);

exp.delete('/locations/:id',routes.location.delete_locations_1e);

exp.post('/locations/',routes.location.post_locations_1f);

exp.get('/parts/',routes.part.get_parts_1g);

exp.get('/parts/:id',routes.part.get_parts_1h);

exp.put('/parts/:id',routes.part.put_parts_1i);

exp.delete('/parts/:id',routes.part.delete_parts_1j);

exp.post('/parts/',routes.part.post_parts_1k);

exp.get('/parts/:id/pallets',routes.part.get_pallets_in_parts_1l);

exp.post('/parts/:id/pallets',routes.part.post_pallets_in_parts_1m);


console.log('The application is listening at port 3001');
exp.listen(3001);