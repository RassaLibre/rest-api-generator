var express = require('express');
var routes = require('./app/routes');
var exp = express();
var bodyParser = require('body-parser')

exp.use(bodyParser.json());       // to support JSON-encoded bodies
exp.use(bodyParser.urlencoded({     // to support URL-encoded bodies
  extended: true
}));


exp.get('/teams/',routes.teams.get_teams_1q);

exp.get('/teams/:id',routes.teams.get_teams_1r);

exp.get('/teams/:id/players',routes.teams.get_players_in_teams_1z);

exp.post('/teams/:id/players',routes.teams.post_players_in_teams_20);

exp.get('/players/',routes.players.get_players_1v);

exp.get('/players/:id',routes.players.get_players_1w);

exp.post('/players/',routes.players.post_players_21);

exp.put('/players/:id',routes.players.put_players_22);


console.log('The application is listening at port 3001');
exp.listen(3001);