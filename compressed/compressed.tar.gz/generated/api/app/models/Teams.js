var Model = require('./model');
var _ = require('underscore');

/**
 * instantiate the model
 */
Teams.prototype = new Model();
Teams.prototype.constructor = Teams;

function Teams() {

  /**
   * set the fields
   */
  this.fields = {

    name: {
      type: 'string',
      length: 30,
      regex: '',
    },

    established: {
      type: 'integer',
      min: 1000,
      max: 2015,
    },

    players: {
      type: 'array',
      key: 'string',
      value: 'Players',
    },

  };
};


module.exports = Teams;