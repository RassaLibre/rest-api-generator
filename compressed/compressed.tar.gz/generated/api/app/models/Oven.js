var Model = require('./model');
var _ = require('underscore');

/**
 * instantiate the model
 */
Oven.prototype = new Model();
Oven.prototype.constructor = Oven;

function Oven() {

  /**
   * set the fields
   */
  this.fields = {

    SKU: {
      type: 'string',
      length: 30,
      regex: '^[A-Z1-9]{2}-[A-Z1-9]{2}$',
    },

    name: {
      type: 'string',
      length: 30,
    },

    parts: {
      type: 'array',
      key: 'integer',
      value: 'Part',
    },

    status: {
      type: 'string',
      length: 30,
    },

    createdAt: {
      type: 'timestamp',

    },

    updatedAt: {
      type: 'timestamp',

    },

    location: {
      type: 'Location',

    },

  };
};


module.exports = Oven;