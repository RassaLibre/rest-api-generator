var Model = require('./model');
var _ = require('underscore');

/**
 * instantiate the model
 */
Oven.prototype = new Model();
Oven.prototype.constructor = Oven;

function Oven() {

  /**
   * set the fields
   */
  this.fields = {
    /**
    name : {type: "string", regex: /^[A-Za-z0-9]+$/i, length: 30},
    value : {type: "integer", min: 0, max: 40},
    price : {type: "integer", min: 0}
    **/

    SKU: {
      type: 'string',

      length: 30,

      regex: '^[A-Z1-9]{2}-[A-Z1-9]{2}$',

    },

    name: {
      type: 'string',

      length: 30,

    },

    parts: {
      type: 'array',

      key: 'integer',

      value: 'Part',

    },

    status: {
      type: 'string',

      length: 30,

    },

    createdAt: {
      type: 'timestamp',

    },

    updatedAt: {
      type: 'timestamp',

    },

    location: {
      type: 'Location',

    },

  };
};


module.exports = Oven;