var Model = require('./model');
var _ = require('underscore');

/**
 * instantiate the model
 */
Location.prototype = new Model();
Location.prototype.constructor = Location;

function Location() {

  /**
   * set the fields
   */
  this.fields = {

    SKU: {
      type: 'string',
      length: 30,
      regex: '[A-Z]{1}[1-9]{2}-[1-9]{2}$',
    },

    name: {
      type: 'string',
      length: 30,
    },

    geoLocation: {
      type: 'geojson',

    },

    createdAt: {
      type: 'timestamp',

    },

    updatedAt: {
      type: 'timestamp',

    },

  };
};


module.exports = Location;