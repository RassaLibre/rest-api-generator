var Model = require('./model');
var _ = require('underscore');

/**
 * instantiate the model
 */
Pallet.prototype = new Model();
Pallet.prototype.constructor = Pallet;

function Pallet() {

  /**
   * set the fields
   */
  this.fields = {

    SKU: {
      type: 'string',
      length: 30,
      regex: '^[A-Z1-9]{2}-[A-Z1-9]{2}$',
    },

    parts: {
      type: 'array',
      key: 'integer',
      value: 'Part',
    },

    location: {
      type: 'Location',

    },

    createdAt: {
      type: 'timestamp',

    },

    updatedAt: {
      type: 'timestamp',

    },

  };
};


module.exports = Pallet;