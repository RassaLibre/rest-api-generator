var Model = require('./model');
var _ = require('underscore');

/**
 * instantiate the model
 */
Players.prototype = new Model();
Players.prototype.constructor = Players;

function Players() {

  /**
   * set the fields
   */
  this.fields = {

    name: {
      type: 'string',
      length: 50,
      regex: '',
    },

    age: {
      type: 'integer',
      min: 18,
      max: 120,
    },

  };
};


module.exports = Players;