var Model = require('./model');
var _ = require('underscore');

/**
 * instantiate the model
 */
Part.prototype = new Model();
Part.prototype.constructor = Part;

function Part() {

  /**
   * set the fields
   */
  this.fields = {

    SKU: {
      type: 'string',
      length: 30,
      regex: '^[1-9]{2}-[A-Z1-9]{2}-[A-Z1-9]{2}$',
    },

    name: {
      type: 'string',
      length: 30,
    },

    count: {
      type: 'integer',
      min: 0,
    },

    price: {
      type: 'double',
      min: 0,
    },

    value: {
      type: 'double',
      min: 0,
    },

    createdAt: {
      type: 'timestamp',

    },

    updatedAt: {
      type: 'timestamp',

    },

  };
};


module.exports = Part;