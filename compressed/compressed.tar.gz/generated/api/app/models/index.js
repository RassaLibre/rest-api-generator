module.exports = {
    Oven: require('./Oven'),
    Pallet: require('./Pallet'),
    Location: require('./Location'),
    Part: require('./Part'),
};