module.exports = {
    Teams: require('./Teams'),
    Players: require('./Players'),
};