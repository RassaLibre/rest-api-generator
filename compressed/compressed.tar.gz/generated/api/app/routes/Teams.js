var error_handler = require('../Error_Map');
var mongo = require('mongodb');
var mongo_client = mongo.MongoClient;
var mongo_url = require('../Db')();
var model = require('../models');
var nested = require('../nested');
var db_query_builder = require('../db_query_builder');

var TeamsController = {



  /**
   * returns list of Teams
   */
  get_teams_1q: function (req, res) {
    mongo_client.connect(mongo_url, function (err, db) {
      if (err) error_handler.send_error(res, 102);
      var collection = db.collection('teams');
      var query_string = db_query_builder.build_db_query(req.query, new model.Teams().fields);
      collection.find(query_string).toArray(function (err, docs) {
        if (err) error_handler.send_error(res, 100);
        res.send(docs);
        db.close();
      });
    });
  },



  /**
   * returns one Teams
   */
  get_teams_1r: function (req, res) {
    mongo_client.connect(mongo_url, function (err, db) {
      if (err) error_handler.send_error(res, 102);
      var collection = db.collection('teams');
      collection.findOne({
          _id: mongo.ObjectID(req.params.id)
        }

        ,
        function (err, doc) {
          if (err) error_handler.send_error(res, 100);
          if (doc) res.send(doc);
          else error_handler.send_error(res, 100);
          db.close();
        });
    });
  },



  /**
   * returns param from Teams
   */
  get_players_in_teams_1z: function (req, res) {
    mongo_client.connect(mongo_url, function (err, db) {
      if (err) error_handler.send_error(res, 102);
      var collection = db.collection('teams');
      collection.findOne({
          _id: mongo.ObjectID(req.params.id)
        }

        ,
        function (err, doc) {
          if (err) error_handler.send_error(res, 100);
          if (doc) res.send(doc.players);
          else error_handler.send_error(res, 100);
          db.close();
        });
    });
  },



  /**
   *
   */
  post_players_in_teams_20: function (req, res) {
    var new_Teams = new model.Player();
    new_Teams.assign(req.body);
    if (!new_Teams.is_valid()) {
      error_handler.send_error(res, 103);
      return;
    }
    mongo_client.connect(mongo_url, function (err, db) {
      if (err) error_handler.send_error(res, 102);
      new_Teams._id = mongo.ObjectID(req.body._id);
      var collection = db.collection('teams');
      collection.update({
        _id: mongo.ObjectID(req.params.id)
      }, {
        $addToSet: {
          players: new_Teams.to_JSON()
        }
      }, function (err, result) {
        if (err) error_handler.send_error(res, 100);
        res.send(new_Teams.to_JSON());
        db.close();
      });
    });
  },



};

module.exports = TeamsController;