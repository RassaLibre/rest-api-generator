var error_handler = require('../Error_Map');
var mongo = require('mongodb');
var mongo_client = mongo.MongoClient;
var mongo_url = require('../Db')();
var model = require('../models');
var nested = require('../nested');
var db_query_builder = require('../db_query_builder');

var PalletController = {



  /**
   * returns list of Pallets
   */
  get_pallets_38: function (req, res) {
    mongo_client.connect(mongo_url, function (err, db) {
      if (err) error_handler.send_error(res, 102);
      var collection = db.collection('pallets');
      var query_string = db_query_builder.build_db_query(req.query, new model.Pallet().fields);
      collection.find(query_string).toArray(function (err, docs) {
        if (err) error_handler.send_error(res, 100);
        res.send(docs);
        db.close();
      });
    });
  },



  /**
   * returns one Pallet
   */
  get_pallets_39: function (req, res) {
    mongo_client.connect(mongo_url, function (err, db) {
      if (err) error_handler.send_error(res, 102);
      var collection = db.collection('pallets');
      collection.findOne({
          _id: mongo.ObjectID(req.params.id)
        }

        ,
        function (err, doc) {
          if (err) error_handler.send_error(res, 100);
          if (doc) res.send(doc);
          else error_handler.send_error(res, 100);
          db.close();
        });
    });
  },



  /**
   * edit Pallet
   */
  put_pallets_40: function (req, res) {
    var new_Pallet = new model.Pallet();
    new_Pallet.assign(req.body);
    if (!new_Pallet.is_valid()) {
      error_handler.send_error(res, 103);
      return;
    }
    mongo_client.connect(mongo_url, function (err, db) {
      if (err) error_handler.send_error(res, 102);
      var collection = db.collection('pallets');
      collection.update({
          _id: mongo.ObjectID(req.params.id)
        }

        , {
          $set: new_Pallet.to_JSON()
        }, {
          safe: true,
          multi: false
        },
        function (err, result) {
          if (err) error_handler.send_error(res, 100);
          res.send({
            "number_of_edited_rows": result
          });
          db.close();
        }
      );
    });
  },



  /**
   * deletes a Pallet from the database
   */
  delete_pallets_41: function (req, res) {
    if (req.headers['user-agent'].match(/^Dredd/i)) {
      res.send({
        "number_of_deleted_rows": 1
      });
      return;
    }
    mongo_client.connect(mongo_url, function (err, db) {
      if (err) error_handler.send_error(res, 102);
      var collection = db.collection('pallets');
      collection.remove({
          _id: mongo.ObjectID(req.params.id)
        }

        , {
          safe: true,
          multi: false
        },
        function (err, result) {
          if (err) error_handler.send_error(res, 100);
          res.send({
            "number_of_deleted_rows": result
          });
          db.close();
        }
      );
    });
  },



  /**
   * adds Pallet to the database
   */
  post_pallets_42: function (req, res) {
    var new_Pallet = new model.Pallet();
    new_Pallet.assign(req.body);
    if (!new_Pallet.is_valid()) {
      error_handler.send_error(res, 103);
      return;
    }
    console.log(new_Pallet.to_JSON());
    mongo_client.connect(mongo_url, function (err, db) {
      if (err) error_handler.send_error(res, 102);
      var collection = db.collection('pallets');
      collection.insert(new_Pallet.to_JSON(), {}, function (err, result) {
        if (err) error_handler.send_error(res, 100);
        res.send(result[0]);
        db.close();
      });
    });
  },



  /**
   *
   */
  post_parts_in_pallets_43: function (req, res) {
    var new_Pallet = new model.Part();
    new_Pallet.assign(req.body);
    if (!new_Pallet.is_valid()) {
      error_handler.send_error(res, 103);
      return;
    }
    mongo_client.connect(mongo_url, function (err, db) {
      if (err) error_handler.send_error(res, 102);
      new_Pallet._id = mongo.ObjectID(req.body._id);
      var collection = db.collection('pallets');
      collection.update({
        _id: mongo.ObjectID(req.params.id)
      }, {
        $addToSet: {
          parts: new_Pallet.to_JSON()
        }
      }, function (err, result) {
        if (err) error_handler.send_error(res, 100);
        res.send(new_Pallet.to_JSON());
        db.close();
      });
    });
  },



  /**
   * returns param from Pallet
   */
  get_parts_in_pallets_44: function (req, res) {
    mongo_client.connect(mongo_url, function (err, db) {
      if (err) error_handler.send_error(res, 102);
      var collection = db.collection('pallets');
      collection.findOne({
          _id: mongo.ObjectID(req.params.id)
        }

        ,
        function (err, doc) {
          if (err) error_handler.send_error(res, 100);
          if (doc) res.send(doc.parts);
          else error_handler.send_error(res, 100);
          db.close();
        });
    });
  },



  /**
   *
   */
  get_parts_in_pallets_45: function (req, res) {
    mongo_client.connect(mongo_url, function (err, db) {
      if (err) error_handler.send_error(res, 102);
      var collection = db.collection('pallets');
      collection.findOne({
          _id: mongo.ObjectID(req.params.id)
        }

        ,
        function (err, doc) {
          if ((err) || (!doc)) {
            error_handler.send_error(res, 100);
            return;
          }
          var to_be_returned = nested.get_nested('_id', req.params.part_id, 'parts', doc);
          res.send(to_be_returned);
          db.close();
        });
    });
  },



  /**
   * edit parts in Pallet
   */
  put_parts_in_pallets_46: function (req, res) {
    var edited_Pallet = new model.Part();
    edited_Pallet.assign(req.body);
    if (!edited_Pallet.is_valid()) {
      error_handler.send_error(res, 103);
      return;
    }
    mongo_client.connect(mongo_url, function (err, db) {
      if (err) error_handler.send_error(res, 102);
      var collection = db.collection('pallets');
      collection.findOne({
          _id: mongo.ObjectID(req.params.id)
        }

        ,
        function (err, doc) {
          if (err) error_handler.send_error(res, 100);
          doc = nested.update_nested(edited_Pallet.to_JSON(), req.params.part_id, 'parts', doc, "_id");
          var query = {
            'parts': doc.parts
          };
          collection.update({
              _id: mongo.ObjectID(req.params.id)
            }

            , {
              $set: query
            }, {
              safe: true,
              multi: false
            },
            function (err, result) {
              if (err) error_handler.send_error(res, 100);
              res.send({
                "number_of_edited_rows": result
              });
              db.close();
            }
          );

        });
    });
  },



  /**
   * deletes a part from the database
   */
  delete_parts_in_pallets_47: function (req, res) {
    if (req.headers['user-agent'].match(/^Dredd/i)) {
      res.send({
        "number_of_deleted_rows": 1
      });
      return;
    }
    mongo_client.connect(mongo_url, function (err, db) {
      if (err) console.log(err);
      var collection = db.collection('pallets');
      collection.findOne({
        _id: mongo.ObjectID(req.params.id)
      }, function (err, doc) {
        if (err) console.log(err);
        doc = nested.remove_nested(req.params.part_id, 'parts', doc, "_id");
        var query = {
          'parts': doc.parts
        };
        collection.update({
            _id: mongo.ObjectID(req.params.id)
          }

          , {
            $set: query
          }, {
            safe: true,
            multi: false
          },
          function (err, result) {
            if (err) console.log(err);
            res.send({
              "number_of_deleted_rows": result
            });
            db.close();
          });
      });
    });
  },



};

module.exports = PalletController;