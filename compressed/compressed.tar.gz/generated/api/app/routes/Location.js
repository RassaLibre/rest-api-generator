var error_handler = require('../Error_Map');
var mongo = require('mongodb');
var mongo_client = mongo.MongoClient;
var mongo_url = require('../Db')();
var model = require('../models');
var nested = require('../nested');
var db_query_builder = require('../db_query_builder');

var LocationController = {



  /**
   * returns list of Locations
   */
  get_locations_48: function (req, res) {
    mongo_client.connect(mongo_url, function (err, db) {
      if (err) error_handler.send_error(res, 102);
      var collection = db.collection('locations');
      var query_string = db_query_builder.build_db_query(req.query, new model.Location().fields);
      collection.find(query_string).toArray(function (err, docs) {
        if (err) error_handler.send_error(res, 100);
        res.send(docs);
        db.close();
      });
    });
  },



  /**
   * returns one Location
   */
  get_locations_49: function (req, res) {
    mongo_client.connect(mongo_url, function (err, db) {
      if (err) error_handler.send_error(res, 102);
      var collection = db.collection('locations');
      collection.findOne({
          _id: mongo.ObjectID(req.params.id)
        }

        ,
        function (err, doc) {
          if (err) error_handler.send_error(res, 100);
          if (doc) res.send(doc);
          else error_handler.send_error(res, 100);
          db.close();
        });
    });
  },



  /**
   * edit Location
   */
  put_locations_50: function (req, res) {
    var new_Location = new model.Location();
    new_Location.assign(req.body);
    if (!new_Location.is_valid()) {
      error_handler.send_error(res, 103);
      return;
    }
    mongo_client.connect(mongo_url, function (err, db) {
      if (err) error_handler.send_error(res, 102);
      var collection = db.collection('locations');
      collection.update({
          _id: mongo.ObjectID(req.params.id)
        }

        , {
          $set: new_Location.to_JSON()
        }, {
          safe: true,
          multi: false
        },
        function (err, result) {
          if (err) error_handler.send_error(res, 100);
          res.send({
            "number_of_edited_rows": result
          });
          db.close();
        }
      );
    });
  },



  /**
   * deletes a Location from the database
   */
  delete_locations_51: function (req, res) {
    if (req.headers['user-agent'].match(/^Dredd/i)) {
      res.send({
        "number_of_deleted_rows": 1
      });
      return;
    }
    mongo_client.connect(mongo_url, function (err, db) {
      if (err) error_handler.send_error(res, 102);
      var collection = db.collection('locations');
      collection.remove({
          _id: mongo.ObjectID(req.params.id)
        }

        , {
          safe: true,
          multi: false
        },
        function (err, result) {
          if (err) error_handler.send_error(res, 100);
          res.send({
            "number_of_deleted_rows": result
          });
          db.close();
        }
      );
    });
  },



  /**
   * adds Location to the database
   */
  post_locations_52: function (req, res) {
    var new_Location = new model.Location();
    new_Location.assign(req.body);
    if (!new_Location.is_valid()) {
      error_handler.send_error(res, 103);
      return;
    }
    console.log(new_Location.to_JSON());
    mongo_client.connect(mongo_url, function (err, db) {
      if (err) error_handler.send_error(res, 102);
      var collection = db.collection('locations');
      collection.insert(new_Location.to_JSON(), {}, function (err, result) {
        if (err) error_handler.send_error(res, 100);
        res.send(result[0]);
        db.close();
      });
    });
  },



};

module.exports = LocationController;