module.exports = {
    oven: require('./Oven'),
    pallet: require('./Pallet'),
    location: require('./Location'),
    part: require('./Part'),
};