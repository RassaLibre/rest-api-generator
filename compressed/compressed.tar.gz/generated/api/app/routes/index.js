module.exports = {
    teams: require('./Teams'),
    players: require('./Players'),
};