var error_handler = require('../Error_Map');
var mongo = require('mongodb');
var mongo_client = mongo.MongoClient;
var mongo_url = require('../Db')();
var model = require('../models');
var nested = require('../nested');
var db_query_builder = require('../db_query_builder');

var PlayersController = {



  /**
   * returns list of Players
   */
  get_players_1v: function (req, res) {
    mongo_client.connect(mongo_url, function (err, db) {
      if (err) error_handler.send_error(res, 102);
      var collection = db.collection('players');
      var query_string = db_query_builder.build_db_query(req.query, new model.Players().fields);
      collection.find(query_string).toArray(function (err, docs) {
        if (err) error_handler.send_error(res, 100);
        res.send(docs);
        db.close();
      });
    });
  },



  /**
   * returns one Players
   */
  get_players_1w: function (req, res) {
    mongo_client.connect(mongo_url, function (err, db) {
      if (err) error_handler.send_error(res, 102);
      var collection = db.collection('players');
      collection.findOne({
          _id: mongo.ObjectID(req.params.id)
        }

        ,
        function (err, doc) {
          if (err) error_handler.send_error(res, 100);
          if (doc) res.send(doc);
          else error_handler.send_error(res, 100);
          db.close();
        });
    });
  },



  /**
   * adds Players to the database
   */
  post_players_21: function (req, res) {
    var new_Players = new model.Players();
    new_Players.assign(req.body);
    if (!new_Players.is_valid()) {
      error_handler.send_error(res, 103);
      return;
    }
    console.log(new_Players.to_JSON());
    mongo_client.connect(mongo_url, function (err, db) {
      if (err) error_handler.send_error(res, 102);
      var collection = db.collection('players');
      collection.insert(new_Players.to_JSON(), {}, function (err, result) {
        if (err) error_handler.send_error(res, 100);
        res.send(result[0]);
        db.close();
      });
    });
  },



  /**
   * edit Players
   */
  put_players_22: function (req, res) {
    var new_Players = new model.Players();
    new_Players.assign(req.body);
    if (!new_Players.is_valid()) {
      error_handler.send_error(res, 103);
      return;
    }
    mongo_client.connect(mongo_url, function (err, db) {
      if (err) error_handler.send_error(res, 102);
      var collection = db.collection('players');
      collection.update({
          _id: mongo.ObjectID(req.params.id)
        }

        , {
          $set: new_Players.to_JSON()
        }, {
          safe: true,
          multi: false
        },
        function (err, result) {
          if (err) error_handler.send_error(res, 100);
          res.send({
            "number_of_edited_rows": result
          });
          db.close();
        }
      );
    });
  },



};

module.exports = PlayersController;