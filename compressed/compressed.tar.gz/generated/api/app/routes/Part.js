var error_handler = require('../Error_Map');
var mongo = require('mongodb');
var mongo_client = mongo.MongoClient;
var mongo_url = require('../Db')();
var model = require('../models');
var nested = require('../nested');
var db_query_builder = require('../db_query_builder');

var PartController = {



  /**
   * returns list of Parts
   */
  get_parts_53: function (req, res) {
    mongo_client.connect(mongo_url, function (err, db) {
      if (err) error_handler.send_error(res, 102);
      var collection = db.collection('parts');
      var query_string = db_query_builder.build_db_query(req.query, new model.Part().fields);
      collection.find(query_string).toArray(function (err, docs) {
        if (err) error_handler.send_error(res, 100);
        res.send(docs);
        db.close();
      });
    });
  },



  /**
   * returns one Part
   */
  get_parts_54: function (req, res) {
    mongo_client.connect(mongo_url, function (err, db) {
      if (err) error_handler.send_error(res, 102);
      var collection = db.collection('parts');
      collection.findOne({
          _id: mongo.ObjectID(req.params.id)
        }

        ,
        function (err, doc) {
          if (err) error_handler.send_error(res, 100);
          if (doc) res.send(doc);
          else error_handler.send_error(res, 100);
          db.close();
        });
    });
  },



  /**
   * edit Part
   */
  put_parts_55: function (req, res) {
    var new_Part = new model.Part();
    new_Part.assign(req.body);
    if (!new_Part.is_valid()) {
      error_handler.send_error(res, 103);
      return;
    }
    mongo_client.connect(mongo_url, function (err, db) {
      if (err) error_handler.send_error(res, 102);
      var collection = db.collection('parts');
      collection.update({
          _id: mongo.ObjectID(req.params.id)
        }

        , {
          $set: new_Part.to_JSON()
        }, {
          safe: true,
          multi: false
        },
        function (err, result) {
          if (err) error_handler.send_error(res, 100);
          res.send({
            "number_of_edited_rows": result
          });
          db.close();
        }
      );
    });
  },



  /**
   * deletes a Part from the database
   */
  delete_parts_56: function (req, res) {
    if (req.headers['user-agent'].match(/^Dredd/i)) {
      res.send({
        "number_of_deleted_rows": 1
      });
      return;
    }
    mongo_client.connect(mongo_url, function (err, db) {
      if (err) error_handler.send_error(res, 102);
      var collection = db.collection('parts');
      collection.remove({
          _id: mongo.ObjectID(req.params.id)
        }

        , {
          safe: true,
          multi: false
        },
        function (err, result) {
          if (err) error_handler.send_error(res, 100);
          res.send({
            "number_of_deleted_rows": result
          });
          db.close();
        }
      );
    });
  },



  /**
   * adds Part to the database
   */
  post_parts_57: function (req, res) {
    var new_Part = new model.Part();
    new_Part.assign(req.body);
    if (!new_Part.is_valid()) {
      error_handler.send_error(res, 103);
      return;
    }
    console.log(new_Part.to_JSON());
    mongo_client.connect(mongo_url, function (err, db) {
      if (err) error_handler.send_error(res, 102);
      var collection = db.collection('parts');
      collection.insert(new_Part.to_JSON(), {}, function (err, result) {
        if (err) error_handler.send_error(res, 100);
        res.send(result[0]);
        db.close();
      });
    });
  },



  get_pallets_in_parts_58: function (req, res) {
    res.status(500).send("Not implemented");
  },



  post_pallets_in_parts_59: function (req, res) {
    res.status(500).send("Not implemented");
  },



};

module.exports = PartController;