var error_handler = require('../Error_Map');
var mongo = require('mongodb');
var mongo_client = mongo.MongoClient;
var mongo_url = require('../Db')();
var model = require('../models');
var nested = require('../nested');

var OvenController = {



  /**
   * returns list of Ovens
   */
  get_ovens_w: function (req, res) {
    mongo_client.connect(mongo_url, function (err, db) {
      if (err) error_handler.send_error(res, 102);
      var collection = db.collection('ovens');
      collection.find({}).toArray(function (err, docs) {
        if (err) error_handler.send_error(res, 100);
        res.send(docs);
        db.close();
      });
    });
  },



  /**
   * returns one Oven
   */
  get_ovens_x: function (req, res) {
    mongo_client.connect(mongo_url, function (err, db) {
      if (err) error_handler.send_error(res, 102);
      var collection = db.collection('ovens');
      collection.findOne({
          _id: mongo.ObjectID(req.params.id)
        }

        ,
        function (err, doc) {
          if (err) error_handler.send_error(res, 100);
          if (doc) res.send(doc);
          else error_handler.send_error(res, 100);
          db.close();
        });
    });
  },



  /**
   * edit Oven
   */
  put_ovens_y: function (req, res) {
    var new_Oven = new model.Oven();
    new_Oven.assign(req.body);
    if (!new_Oven.is_valid()) {
      error_handler.send_error(res, 103);
      return;
    }
    mongo_client.connect(mongo_url, function (err, db) {
      if (err) error_handler.send_error(res, 102);
      var collection = db.collection('ovens');
      collection.update({
          _id: mongo.ObjectID(req.params.id)
        }

        , {
          $set: new_Oven.to_JSON()
        }, {
          safe: true,
          multi: false
        },
        function (err, result) {
          if (err) error_handler.send_error(res, 100);
          res.send({
            "number_of_edited_rows": result
          });
          db.close();
        }
      );
    });
  },



  /**
   * deletes a Oven from the database
   */
  delete_ovens_z: function (req, res) {
    if (req.headers['user-agent'].match(/^Dredd/i)) {
      res.send({
        "number_of_deleted_rows": 1
      });
      return;
    }
    mongo_client.connect(mongo_url, function (err, db) {
      if (err) error_handler.send_error(res, 102);
      var collection = db.collection('ovens');
      collection.remove({
          _id: mongo.ObjectID(req.params.id)
        }

        , {
          safe: true,
          multi: false
        },
        function (err, result) {
          if (err) error_handler.send_error(res, 100);
          res.send({
            "number_of_deleted_rows": result
          });
          db.close();
        }
      );
    });
  },



  /**
   * adds Oven to the database
   */
  post_ovens_10: function (req, res) {
    var new_Oven = new model.Oven();
    new_Oven.assign(req.body);
    if (!new_Oven.is_valid()) {
      error_handler.send_error(res, 103);
      return;
    }
    console.log(new_Oven.to_JSON());
    mongo_client.connect(mongo_url, function (err, db) {
      if (err) error_handler.send_error(res, 102);
      var collection = db.collection('ovens');
      collection.insert(new_Oven.to_JSON(), {}, function (err, result) {
        if (err) error_handler.send_error(res, 100);
        res.send(result[0]);
        db.close();
      });
    });
  },



};

module.exports = OvenController;