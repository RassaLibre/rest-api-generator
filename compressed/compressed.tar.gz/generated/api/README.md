#GENERATED REST API
Generated API from the generator. Aaaand this is just because I need some change in the templates! This one will be uploaded to github template repo and then we will see if it will show up in the final result. Aaaand let me see if it works with the config file. Digs presentation!
