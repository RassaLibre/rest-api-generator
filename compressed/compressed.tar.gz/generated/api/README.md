#GENERATED REST API
Generated API from the generator.